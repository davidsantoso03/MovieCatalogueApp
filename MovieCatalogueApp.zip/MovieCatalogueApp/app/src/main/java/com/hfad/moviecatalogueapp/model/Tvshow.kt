package com.hfad.moviecatalogueapp.model

data class Tvshow(
        var tvId : String,
        var title: String,
        var description :String,
        var image:String,
        var date : String,
        var category: String,
        var score : String,
        var creator : String,
        var Duration :String
)
